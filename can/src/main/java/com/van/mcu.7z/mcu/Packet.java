package com.van.mcu;

public class Packet {
    private final int mCmd;
    private byte[]  mBody;   // 消息体内容


    public Packet(int cmd) {
        mCmd = cmd;
    }

    public void reset() {
        mBody = null;
    }

    public int getCmd() {
        return mCmd;
    }

	public byte[] getBody() {
        return mBody;
    }

    public void setBody(byte[] body) {
        reset();
        mBody = body;
    }

    public byte[] build() {
        int bodySize = (null!=mBody) ? mBody.length : 0;

        int length = bodySize + 7;
        byte[] buf = new byte[length];

        buf[0] = 0x02;
        buf[1] = 0x5B;
        buf[2] = (byte)(mCmd&0xFF);
        buf[3] = (byte)bodySize;
        buf[4] = Utils.CRC8(buf, 4);

        if (bodySize > 0) {
            System.arraycopy(mBody, 0, buf, 5, bodySize);
        }

        buf[length-2] = 0x5D;
        buf[length-1] = 0x03;

        return buf;
    }
}
