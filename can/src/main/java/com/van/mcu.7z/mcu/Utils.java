package com.van.mcu;

public class Utils {
    public static byte CRC8(byte[] buf, int length) {
        byte crc = 0;

        for (int i=0; i<length; ++i) {
            crc ^= buf[i];

            for (int j = 8; j > 0; --j)
            {
                if ((crc & 0x80) != 0) {
                    crc = (byte)((crc << 1) ^ 0x31);
                } else {
                    crc = (byte)(crc << 1);
                }
            }
        }

        return crc;
    }

    public static int getInt(byte[] buf, int pos, int size) {
        int value = 0;

        switch (size) {
            case 1:
                value = buf[pos] & 0xFF;
                break;
            case 2:
                value = ((buf[pos] & 0xFF) << 8) + (buf[pos+1] & 0xFF);
                break;
            case 4:
                value = ((buf[pos] & 0xFF) << 24) + ((buf[pos+1] & 0xFF) << 16) + ((buf[pos+2] & 0xFF) << 8) + (buf[pos+3] & 0xFF);
                break;
            default:
                break;
        }

        return value;
    }

    public static void writeInt(byte[] buf, int offset, int value) {
        buf[offset++] = (byte) (value >> 24);
        buf[offset++] = (byte) ((value >> 16) & 0xFF);
        buf[offset++] = (byte) ((value >> 8) & 0xFF);
        buf[offset++] = (byte) (value & 0xFF);
    }

    public static void showHex(byte[] data, int length) {
        String str = "";

        StringBuilder sb = new StringBuilder(length*3);

        final char[] HEX = {'0', '1', '2', '3', '4', '5', '6', '7',
                '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

        for (int i = 0; i < length; i++) {
            int value = data[i] & 0xff;
            sb.append(HEX[value/16]).append(HEX[value%16]).append(' ');
        }

        str = sb.substring(0, sb.length()-1);

        System.out.println("--- " + str);
    }
}
