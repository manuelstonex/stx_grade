package com.van.mcu;

import android.text.TextUtils;

import java.io.UnsupportedEncodingException;

public class VcxCmd extends VcxCore {
    private static VcxCmd _instance;

    private VcxCmd() {
        mClient.start();
    }

    public static VcxCmd instance() {
        if (null == _instance) {
            synchronized (VcxCmd.class) {
                if (null == _instance) {
                    _instance = new VcxCmd();
                }
            }
        }

        return _instance;
    }

    public String getVersion() {
        Packet packet = new Packet(CmdID.GET_VERSION);
        Packet resp = null;

        try {
            resp = mRequest.request(packet, 2000);
        } catch (Exception e) {
            return "";
        }

        return new String(resp.getBody());
    }

    public int getAccState() {
        Packet packet = new Packet(CmdID.ACC_GET);
        Packet resp = null;

        try {
            resp = mRequest.request(packet, 2000);
        } catch (Exception e) {
            return -1;
        }

        return resp.getBody()[0];
    }

    public boolean powerCtrl(int val) {
        byte[] data = new byte[1];
        data[0] = (byte)val;

        Packet packet = new Packet(CmdID.POWER_CTRL);
        packet.setBody(data);

        try {
            mRequest.request(packet, 2000);
        } catch (Exception e) {
            return false;
        }

        return true;
    }

    public int getPowerVoltage() {
        Packet packet = new Packet(CmdID.GET_POWER_VOLTAGE);
        Packet resp = null;

        try {
            resp = mRequest.request(packet, 2000);
        } catch (Exception e) {
            return 0;
        }

        if (null == resp) {
            return 0;
        }

        return Utils.getInt(resp.getBody(), 0, 4);
    }

    public int getCanCount() {
        Packet packet = new Packet(CmdID.CAN_COUNT);
        Packet resp = null;

        try {
            resp = mRequest.request(packet, 2000);
        } catch (Exception e) {
            return 0;
        }

        if (null == resp) {
            return 0;
        }

        return resp.getBody()[0];
    }

    public int getCanSpeed(int channel) {
        byte[] data = new byte[1];
        data[0] = (byte)channel;

        Packet packet = new Packet(CmdID.CAN_GET_BAUDRATE);
        packet.setBody(data);
        Packet resp = null;

        try {
            resp = mRequest.request(packet, 2000);
        } catch (Exception e) {
            return 0;
        }

        if (null == resp) {
            return 0;
        }

        return Utils.getInt(resp.getBody(), 0, 4);
    }

    public boolean setCanSpeed(int channel, int value) {
        byte[] buf = new byte[5];
        buf[0] = (byte)channel;
        Utils.writeInt(buf, 1, value);

        Packet packet = new Packet(CmdID.CAN_SET_BAUDRATE);
        packet.setBody(buf);

        try {
            mRequest.request(packet, 2000);
        } catch (Exception e) {
            return false;
        }

        return true;
    }

    public boolean canWrite(int channel, int id, byte[] data) {
        if (channel<0 || channel>1) {
            return false;
        }

        int dataSize = data!=null ? data.length : 0;

        if (dataSize > 8) {
            return false;
        }

        byte[] buf = new byte[6 + dataSize];

        buf[0] = (byte)channel;
        Utils.writeInt(buf, 1, id);
        buf[5] = (byte)dataSize;

        if (dataSize > 0) {
            System.arraycopy(data, 0, buf, 6, dataSize);
        }

        Packet packet = new Packet(CmdID.CAN_WRITE);
        packet.setBody(buf);

        try {
            mRequest.request(packet, 0);
        } catch (Exception e) {
            return false;
        }

        return true;
    }

    public boolean canFilterCtrl(int channel, int type) {
        byte[] buf = new byte[2];
        buf[0] = (byte)channel;
        buf[1] = (byte)type;

        Packet packet = new Packet(CmdID.CAN_FILTER_CTRL);
        packet.setBody(buf);

        try {
            mRequest.request(packet, 2000);
        } catch (Exception e) {
            return false;
        }

        return true;
    }

    public boolean canHwFilterAdd(int channel, int id, int mask) {
        byte[] buf = new byte[9];
        buf[0] = (byte)channel;

        Utils.writeInt(buf, 1, id);
        Utils.writeInt(buf, 5, mask);

        Packet packet = new Packet(CmdID.CAN_HW_FILTER_ADD);
        packet.setBody(buf);

        try {
            mRequest.request(packet, 2000);
        } catch (Exception e) {
            return false;
        }

        return true;
    }

    public boolean canHwFilterClear(int channel) {
        byte[] buf = new byte[1];
        buf[0] = (byte)channel;

        Packet packet = new Packet(CmdID.CAN_HW_FILTER_CLEAR);
        packet.setBody(buf);

        try {
            mRequest.request(packet, 2000);
        } catch (Exception e) {
            return false;
        }

        return true;
    }

    public boolean canSwFilterAdd(int channel, int id, int mask) {
        byte[] buf = new byte[9];
        buf[0] = (byte)channel;

        Utils.writeInt(buf, 1, id);
        Utils.writeInt(buf, 5, mask);

        Packet packet = new Packet(CmdID.CAN_SW_FILTER_ADD);
        packet.setBody(buf);

        try {
            mRequest.request(packet, 2000);
        } catch (Exception e) {
            return false;
        }

        return true;
    }

    public boolean canSwFilterClear(int channel) {
        byte[] buf = new byte[1];
        buf[0] = (byte)channel;

        Packet packet = new Packet(CmdID.CAN_SW_FILTER_CLEAR);
        packet.setBody(buf);

        try {
            mRequest.request(packet, 2000);
        } catch (Exception e) {
            return false;
        }

        return true;
    }

    public int getBlockCount() {
        Packet packet = new Packet(CmdID.BLOCK_COUNT);
        Packet resp = null;

        try {
            resp = mRequest.request(packet, 2000);
        } catch (Exception e) {
            return 0;
        }

        if (null == resp) {
            return 0;
        }

        return resp.getBody()[0];
    }

    public boolean blockWrite(int index, byte[] data) {
        int dataSize = data!=null ? data.length : 0;

        if (dataSize > 250) {
            return false;
        }

        byte[] buf = new byte[dataSize+2];
        buf[0] = (byte) index;
        buf[1] = (byte) (dataSize&0xFF);

        if (dataSize > 0) {
            System.arraycopy(data, 0, buf, 2, dataSize);
        }

        Packet packet = new Packet(CmdID.BLOCK_WRITE);
        packet.setBody(buf);

        try {
            mRequest.request(packet, 2000);
        } catch (Exception e) {
            return false;
        }

        return true;
    }

    public boolean blockRead(int index, byte[] buf, int length) {
        if (length>250 || buf.length<length) {
            return false;
        }

        byte[] body = new byte[2];
        body[0] = (byte)index;
        body[1] = (byte)(length&0xFF);

        Packet packet = new Packet(CmdID.BLOCK_READ);
        packet.setBody(body);
        Packet resp = null;

        try {
            resp = mRequest.request(packet, 2000);
        } catch (Exception e) {
            return false;
        }

        if (null == resp) {
            return false;
        }

        System.arraycopy(resp.getBody(), 0, buf, 0, resp.getBody().length);
        return true;
    }

    public int getInputCount() {
        Packet packet = new Packet(CmdID.INPUT_COUNT);
        Packet resp = null;

        try {
            resp = mRequest.request(packet, 2000);
        } catch (Exception e) {
            return 0;
        }

        if (null == resp) {
            return 0;
        }

        return resp.getBody()[0];
    }

    public int inputGet(int index) {
        byte[] buf = new byte[1];
        buf[0] = (byte)index;

        Packet packet = new Packet(CmdID.INPUT_GET);
        packet.setBody(buf);
        Packet resp = null;

        try {
            resp = mRequest.request(packet, 2000);
        } catch (Exception e) {
            return 0;
        }

        return resp.getBody()[0];
    }

    public int getOutputCount() {
        Packet packet = new Packet(CmdID.OUTPUT_COUNT);
        Packet resp = null;

        try {
            resp = mRequest.request(packet, 2000);
        } catch (Exception e) {
            return 0;
        }

        if (null == resp) {
            return 0;
        }

        return resp.getBody()[0];
    }

    public int outputGet(int index) {
        byte[] buf = new byte[1];
        buf[0] = (byte)index;

        Packet packet = new Packet(CmdID.OUTPUT_GET);
        packet.setBody(buf);
        Packet resp = null;

        try {
            resp = mRequest.request(packet, 2000);
        } catch (Exception e) {
            return 0;
        }

        return resp.getBody()[0];
    }

    public boolean outputSet(int index, int value) {
        byte[] buf = new byte[2];
        buf[0] = (byte)index;
        buf[1] = (byte)value;

        Packet packet = new Packet(CmdID.OUTPUT_SET);
        packet.setBody(buf);

        try {
            mRequest.request(packet, 2000);
        } catch (Exception e) {
            return false;
        }

        return true;
    }

    public boolean setCallback(int filter) {
        byte[] buf = new byte[1];
        buf[0] = (byte)filter;

        Packet packet = new Packet(CmdID.CALLBACK_SET);
        packet.setBody(buf);

        try {
            mRequest.request(packet, 2000);
        } catch (Exception e) {
            return false;
        }

        return true;
    }

    public boolean updateMcu(String path) {
        if (TextUtils.isEmpty(path)) {
            return false;
        }

        byte[] buf = null;
        try {
            buf = path.getBytes("utf-8");
        } catch (UnsupportedEncodingException e) {
            return false;
        }

        Packet packet = new Packet(CmdID.UPDATE_MCU);
        packet.setBody(buf);

        try {
            mRequest.request(packet, 10000);
        } catch (Exception e) {
            return false;
        }

        return true;
    }
}
