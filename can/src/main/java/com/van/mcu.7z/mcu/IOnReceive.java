package com.van.mcu;

public interface IOnReceive {
    void onReceive(byte[] data, int length);
}
