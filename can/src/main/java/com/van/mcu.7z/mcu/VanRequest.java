package com.van.mcu;

import android.text.TextUtils;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class VanRequest {
    private Packet  mRespPacket;
    private ISender mSender;
    private int     mReqCmd;    // 请求的命令
    private boolean mTimeoutFlag;

    public VanRequest() {
        mReqCmd = -1;
    }

	public synchronized Packet request(Packet packet, int timeout) throws Exception {
        if (!mSender.isConnected()) {
            Thread.sleep(50);

            if (!mSender.isConnected()) {
                throw new IOException("EC_NOT_CONNECTED");
            }
        }

        Exception exception = null;
        try {
            requestInner(packet, timeout);
        } catch (Exception e) {
            exception = e;
        }

        mReqCmd = -1;
        if (null != exception) {
            throw exception;
        }

        if (null!=mRespPacket && 0x81==mRespPacket.getCmd()) {
            int result = mRespPacket.getBody()[1];

            mRespPacket = null;
            String str;

            switch (result) {
                case 0:
                    str = null;
                    break;
                case 1:
                    str = "EC_EXCUTE_FAILED";
                    break;
                case 2:
                    str = "EC_MSG_ERROR";
                    break;
                case 3:
                    str = "EC_UNSUPPORTED";
                    break;
                default:
                    str = "Unknown";
            }

            if (!TextUtils.isEmpty(str)) {
                throw new Exception(str);
            }
        }

        return mRespPacket;
    }

    public void setSender(ISender sender) {
        mSender = sender;
    }

    private void requestInner(Packet packet, int timeout) throws Exception {
        packet.build();
        mReqCmd = packet.getCmd();
        mRespPacket = null;
        byte[] data = packet.build();

        if (!mSender.send(data, data.length)) {
            throw new Exception("EC_SEND_FAILED");
        }

        if (timeout <= 0) {
            return;
        }

        mTimeoutFlag = true;

        wait(timeout);

        if (mTimeoutFlag) {
            throw new TimeoutException();
        }
    }

    public synchronized void onReceivePacket(Packet packet) {
        int cmd = packet.getCmd();

        if (-1 != mReqCmd) {
            if ((0x81==cmd && mReqCmd==packet.getBody()[0]) || (cmd-0x80 == mReqCmd)) {
                mTimeoutFlag = false;
                mRespPacket = packet;
                notifyAll();
            }
        }
    }
}
