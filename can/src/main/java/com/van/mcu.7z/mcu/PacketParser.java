package com.van.mcu;

public class PacketParser {
    private static final int BUF_SIZE = 4096;
    private static final int MIN_PACK_SIZE = 7;

    private byte[] mBuffer;
    private int    mLength;
    private IOnPacket mOnPacket;

    public PacketParser() {
        mBuffer = new byte[BUF_SIZE];
    }

    public void reset() {
        mLength = 0;
    }

    public void setOnPacket(IOnPacket onPacket) {
        mOnPacket = onPacket;
    }

    public void parse(byte[] buf, int length) {
        int newLength = mLength + length;
        if (newLength > BUF_SIZE) {
            int dropSize = newLength - BUF_SIZE;
            mLength -= dropSize;
            System.arraycopy(mBuffer, dropSize, mBuffer, 0, mLength);
        }

        System.arraycopy(buf, 0, mBuffer, mLength, length);
        mLength += length;

        while (mLength >= MIN_PACK_SIZE) {
            if (!parsePack()) {
                break;
            }
        }
    }

    public boolean parsePack() {
        int nMaxHeadPos = mLength - MIN_PACK_SIZE;

        for (int i = 0; i <= nMaxHeadPos; ++i) {
            if (mBuffer[i] == 0x02 && mBuffer[i + 1] == 0x5B) {
                int bodySize = mBuffer[i + 3] & 0xFF;
                int tail = i + bodySize + MIN_PACK_SIZE;
                if (tail > mLength) {
                    ++i;
                    continue;
                }

                if (mBuffer[tail - 2] != 0x5D || mBuffer[tail - 1] != 0x03) {
                    ++i;
                    continue;
                }

                byte crc = Utils.CRC8(mBuffer, 4);
                if (crc != mBuffer[i + 4]) {
                    ++i;
                    continue;
                }

                Packet packet = new Packet(mBuffer[i + 2] & 0xFF);
                if (bodySize > 0) {
                    byte[] body = new byte[bodySize];
                    System.arraycopy(mBuffer, i+5, body, 0, bodySize);
                    packet.setBody(body);
                }

                if (null != mOnPacket) {
                    mOnPacket.onPacket(packet);
                }

                System.arraycopy(mBuffer, tail, mBuffer, 0, mLength - tail);
                mLength -= tail;

                return true;
            }
        }

        return false;
    }
}
