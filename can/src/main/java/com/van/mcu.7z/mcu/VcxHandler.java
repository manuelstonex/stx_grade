package com.van.mcu;

public class VcxHandler {
    public void handle(Packet packet) {
        VcxMcu.handle(packet);
    }
}
