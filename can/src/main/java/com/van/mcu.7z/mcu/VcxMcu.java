package com.van.mcu;

import android.util.Log;

public class VcxMcu {
    private static VcxCmd _instance;

    static {
        _instance = VcxCmd.instance();
    }

    public interface OnAccListener {
        void OnAcc(int val);    // val 1-ACC ON, 0-ACC OFF.
    }

    public interface OnCanListener {
        void OnCan(int channel, int id, byte[] data);
    }

    public interface OnInputListener {
        void OnInput(int index, int val);   // val 1-High, 0-Low.
    }

    public interface OnDebugListener {
        void OnDebug(String str);
    }

    public static int CAN_EFF_FLAG = 0x80000000;
    public static int CAN_RTR_FLAG = 0x40000000;
    private static OnAccListener mAccListener;
    private static OnCanListener mCanListener;
    private static OnInputListener mInputListener;
    private static OnDebugListener mDebugListener;
    private static int mFilter;

    private static final int ACC    = 0x01;
    private static final int CAN    = 0x02;
    private static final int INPUT  = 0x04;
    private static final int DEBUG  = 0x08;

    public static void setOnAccListener(OnAccListener l) {
        mAccListener = l;
        int filter = mFilter;

        if (null != l) {
            filter |= ACC;
        } else {
            filter &= ~ACC;
        }

        if (filter != mFilter) {
            mFilter = filter;
            setCallback(filter);
        }
    }

    public static void setOnCanListener(OnCanListener l) {
        mCanListener = l;
        int filter = mFilter;

        if (null != l) {
            filter |= CAN;
        } else {
            filter &= ~CAN;
        }

        if (filter != mFilter) {
            mFilter = filter;
            setCallback(filter);
        }
    }

    public static void setOnInputListener(OnInputListener l) {
        mInputListener = l;
        int filter = mFilter;

        if (null != l) {
            filter |= INPUT;
        } else {
            filter &= ~INPUT;
        }

        if (filter != mFilter) {
            mFilter = filter;
            setCallback(filter);
        }
    }

    public static void setOnDebugListener(OnDebugListener l) {
        mDebugListener = l;
        int filter = mFilter;

        if (null != l) {
            filter |= DEBUG;
        } else {
            filter &= ~DEBUG;
        }

        if (filter != mFilter) {
            mFilter = filter;
            setCallback(filter);
        }
    }

    public static String getVersion() {
        return _instance.getVersion();
    }

    public static int getAccState() {
        return _instance.getAccState();
    }

    public static boolean powerCtrl(int val) {
        return _instance.powerCtrl(val);
    }

    public static int getPowerVoltage() {
        return _instance.getPowerVoltage();
    }

    public static int getCanCount() {
        return _instance.getCanCount();
    }

    public static int getCanSpeed(int channel) {
        return _instance.getCanSpeed(channel);
    }

    public static boolean setCanSpeed(int channel, int value) {
        return _instance.setCanSpeed(channel, value);
    }

    public static boolean canWrite(int channel, int id, byte[] data) {
        return _instance.canWrite(channel, id, data);
    }

    /**
     *
     * @param channel
     * @param type 0-disable filter, 1-hardware filter, 2-software filter
     * @return
     */
    public static boolean canFilterCtrl(int channel, int type) {
        return _instance.canFilterCtrl(channel, type);
    }

    public static boolean canHwFilterAdd(int channel, int id, int mask) {
        return _instance.canHwFilterAdd(channel, id, mask);
    }

    public static boolean canHwFilterClear(int channel) {
        return _instance.canHwFilterClear(channel);
    }

    public static boolean canSwFilterAdd(int channel, int id, int mask) {
        return _instance.canSwFilterAdd(channel, id, mask);
    }

    public static boolean canSwFilterClear(int channel) {
        return _instance.canHwFilterClear(channel);
    }

    public static int getBlockCount() {
        return _instance.getBlockCount();
    }

    public static boolean blockWrite(int index, byte[] data) {
        return _instance.blockWrite(index, data);
    }

    public static boolean blockRead(int index, byte[] buf, int length) {
        return _instance.blockRead(index, buf, length);
    }

    public static int getInputCount() {
        return _instance.getInputCount();
    }

    public static int inputGet(int index) {
        return _instance.inputGet(index);
    }

    public static int getOutputCount() {
        return _instance.getOutputCount();
    }

    public static int outputGet(int index) {
        return _instance.outputGet(index);
    }

    public static boolean outputSet(int index, int value) {
        return _instance.outputSet(index, value);
    }

    public static boolean updateFirmware(String path) {
        return _instance.updateMcu(path);
    }

    private static boolean setCallback(int filter) {
        return _instance.setCallback(filter);
    }

    static int count = 0;

    public static void handle(Packet packet) {
        int cmd = packet.getCmd();
        byte[] data = packet.getBody();

        switch (cmd) {
            case CmdID.APP_STARTED:
                System.out.println("Mcu Started.");
                break;
            case CmdID.DEBUG_STRING:
                if (null != mDebugListener) {
                    mDebugListener.OnDebug(new String(data));
                }
                break;
            case CmdID.ACC_PUSH:
                if (null != mAccListener) {
                    mAccListener.OnAcc(data[0]);
                }
                break;
            case CmdID.INPUT_PUSH:
                if (null != mInputListener) {
                    mInputListener.OnInput(data[0], data[1]);
                }
                break;
            case CmdID.CAN_READ:
                if (null != mCanListener) {
                    ++count;
                    Log.e("11", "AA " +count);
                    //mCanListener.OnCan(data[0], );
                }
                break;
        }
    }
}
