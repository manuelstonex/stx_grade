package com.van.mcu;

public interface IOnPacket {
    void onPacket(Packet packet);
}
