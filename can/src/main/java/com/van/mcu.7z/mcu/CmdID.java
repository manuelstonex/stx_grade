package com.van.mcu;

public class CmdID {
    public static final int APP_STARTED            = 0x01;	// MCU App Started
    public static final int DEBUG_STRING           = 0x02;	// MCU Debug String
    public static final int GET_VERSION            = 0x03;	// Get MCU Version
    public static final int ACC_GET                = 0x04;	//
    public static final int ACC_PUSH               = 0x05;	//
    public static final int POWER_CTRL             = 0x06;	//
    public static final int GET_POWER_VOLTAGE      = 0x07;	//
    public static final int CAN_COUNT			   = 0x0F;	//
    public static final int CAN_GET_BAUDRATE       = 0x10;	//
    public static final int CAN_SET_BAUDRATE       = 0x11;	//
    public static final int CAN_WRITE              = 0x12;	//
    public static final int CAN_READ               = 0x13;	//
    public static final int CAN_FILTER_CTRL        = 0x14;	//
    public static final int CAN_HW_FILTER_ADD      = 0x15;	//
    public static final int CAN_HW_FILTER_CLEAR    = 0x16;	//
    public static final int CAN_SW_FILTER_ADD      = 0x17;	//
    public static final int CAN_SW_FILTER_CLEAR    = 0x18;	//
    public static final int BLOCK_COUNT            = 0x19;	//
    public static final int BLOCK_WRITE            = 0x1A;	//
    public static final int BLOCK_READ             = 0x1B;	//
    public static final int INPUT_COUNT            = 0x1C;	//
    public static final int INPUT_GET              = 0x1D;	//
    public static final int INPUT_PUSH             = 0x1E;	//
    public static final int OUTPUT_COUNT           = 0x1F;	//
    public static final int OUTPUT_GET             = 0x20;	//
    public static final int OUTPUT_SET             = 0x21;	//
    public static final int UPDATE_MCU         	   = 0x22; //

    public static final int CALLBACK_SET           = 0x40;	//
}
