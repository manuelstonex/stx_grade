package com.van.mcu;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;

public class VanClient {
    private Thread readThread;

    private Socket socket = null;
    private InputStream is = null;
    private OutputStream os = null;
    private boolean mIsRunning;
    private boolean mIsConnected;
    private IOnReceive mOnReceive;

    public VanClient() {
    }

    public void start() {
        stop();

        mIsRunning = true;
        readThread = new Thread() {
            @Override
            public void run() {
                while (mIsRunning) {
                    work();

                    mIsConnected = false;

                    if (mIsRunning) {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                        }
                    }
                }
            }
        };

        readThread.start();
    }

    public synchronized void stop() {
        mIsRunning = false;
        closeSocket();

        if (readThread!=null && readThread.isAlive()) {
            try {
                readThread.join();
            } catch (InterruptedException e) {
            }
        }

        readThread = null;
    }

    public void closeSocket() {
        mIsConnected = false;

        if (is != null) {
            try {
                is.close();
            } catch (IOException e) {
            }

            is = null;
        }

        if (os != null) {
            try {
                os.close();
            } catch (IOException e) {
            }

            os = null;
        }

        if (socket != null) {
            try {
                socket.shutdownInput();
                socket.shutdownOutput();
                socket.close();
            } catch (IOException e) {
            }

            socket = null;
        }
    }

    public void setOnReceive(IOnReceive listener) {
        mOnReceive = listener;
    }

    public boolean send(final byte[] data, final int length) {
        if (null==os || !isConnected()) {
            return false;
        }

        /*System.out.println("Send:");
        Utils.showHex(data, length);*/

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    os.write(data, 0, length);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();

        /*try {
            System.out.println("Send 0000:  " + length);
            os.write(data, 0, length);
            System.out.println("Send 1111:");
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }*/

        //System.out.println("Send OK:");
        return true;
    }

    public boolean isConnected() {
        return mIsConnected;
    }

    private boolean connect() {
        if (mIsConnected) {
            return true;
        }

        try {
            socket = new Socket();
            socket.setSoTimeout(10000);

            InetSocketAddress address = new InetSocketAddress("127.0.0.1", 8210);
            socket.connect(address, 1000);

            os = socket.getOutputStream();
            is = socket.getInputStream();

            mIsConnected = true;
        } catch (Exception e) {
            closeSocket();
        }

        return mIsConnected;
    }

    private void work() {
        if (!connect()) {
            return;
        }

        System.out.println("Connect!!!\n");

        try {
            byte[] data = new byte[4096];
            int length = 0;

            while (mIsRunning) {
                try {
                    length = is.read(data);
                } catch (Exception e) {
                    if (e instanceof SocketTimeoutException) {
                        continue;
                    } else {
                        e.printStackTrace();
                        throw e;
                    }
                }

                if (length > 0) {
                    /*System.out.println("Recv:");
                    Utils.showHex(data, length);*/
                    if (null != mOnReceive) {
                        mOnReceive.onReceive(data, length);
                    }
                } else if (-1 == length) {
                    break;
                }
            }
        } catch (Exception e) {
        } finally {
            closeSocket();
        }
    }
}
