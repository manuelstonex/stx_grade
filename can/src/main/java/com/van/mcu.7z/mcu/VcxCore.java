package com.van.mcu;

public class VcxCore implements ISender, IOnReceive, IOnPacket {
    protected VcxHandler   mHandler;
    protected PacketParser mParser;
    protected VanRequest   mRequest;
    protected VanClient    mClient;

    public VcxCore() {
        mClient  = new VanClient();
        mParser  = new PacketParser();
        mHandler = new VcxHandler();
        mRequest = new VanRequest();

        mClient.setOnReceive(this);
        mParser.setOnPacket(this);
        mRequest.setSender(this);
    }

    @Override
    public boolean isConnected() {
        return mClient.isConnected();
    }

    @Override
    public boolean send(byte[] data, int length) {
        return mClient.send(data, length);
    }

    @Override
    public void onReceive(byte[] data, int length) {
        mParser.parse(data, length);
    }

    @Override
    public void onPacket(Packet packet) {
        if (packet.getCmd() < 0x80) {
            mHandler.handle(packet);
        } else {
            mRequest.onReceivePacket(packet);
        }
    }
}
