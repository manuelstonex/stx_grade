package com.van.mcu;

public interface ISender {
    boolean isConnected();
    boolean send(byte[] data, int length);
}
